# ULX3S Pinout

WARNING - under development, incomplete

![pinout_ulx3s_v2.png](./pinout_ulx3s_v2.png)

## THIS IS JUST A FORK FOR DEVELOPING & EXPERIMENTING WITH ULX3S PINOUT

Various pinout visuals for the ulx3s are likely to appear (and disappear) here. Content here is **_not_** necessarily correct. Please refer to the official docs for reference:
- https://github.com/ulx3s
- http://radiona.org/ulx3s/