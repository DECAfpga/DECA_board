# DECA FGPA Pinout

![pinout_deca](pinout_deca.png)



Made with [Pinout](https://github.com/j0ono0/pinout). For more information on *pinout* please visit [pinout.readthedocs.io](https://pinout.readthedocs.io/).

